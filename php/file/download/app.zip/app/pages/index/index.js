//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
   autoPlay: true
  },
  
  onLoad: function () {
    this.audioCtx = wx.createAudioContext('myAudio');
    this.audioCtx.play();
  },
  play: function() {
    if(this.data.autoPlay==false){
      this.audioCtx.play();
      this.setData({
        autoPlay: true
      });
    } else {
      this.audioCtx.pause();
      this.setData({
        autoPlay: false
      });
    }
  }
  
})
